The *.sh shell scripts contain the scripts used to run the ML searches and bootstrapping, respectively.

The result files:
  - RAxML_bootstrap.out => bootstrapping trees
  - RAxML_bestTree.nwk => ML tree
  - tree_with_support_rerooted.nwk => ML tree, rerooted and annotated with bootstrap values
