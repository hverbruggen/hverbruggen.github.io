#!/bin/bash
raxmlHPC-PTHREADS -s aln.phyml -n out -m GTRGAMMA -e 0.001 -T 8 -N 200 -o C_adhaerens.1 -q parts