#!/bin/sh
#PBS -N refractumraxml
#PBS -o output.txt
#PBS -e error.txt
#PBS -l walltime=10:00:00
#PBS -l nodes=1:ppn=8

cd $PBS_O_WORKDIR
raxmlHPC-PTHREADS -s aln.phyml -n out -m GTRGAMMA -b 123 -e 1 -T 8 -N 1000 -o C_adhaerens.1 -q parts
