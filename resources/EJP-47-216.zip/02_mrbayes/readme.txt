The nexus file "mb_job.nex" was run 5 times independently in MrBayes 3.1.2

The 3rd and 4th run were selected and summarized with a burnin of 1001 trees.

Results:
  - mb_job.nex.con.tree => consensus tree
  - mb_job.nex.parts => bipartition support