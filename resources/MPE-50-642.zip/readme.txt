siphonous.nex -- alignment with MrBayes analysis block (nexus format)
BI_tree.con -- majority rule consensus tree from MrBayes (nexus format)
ML_tree.nwk -- ML tree from TreeFinder (newick format)
supplement.pdf -- supplementary materials with paper (PDF format)